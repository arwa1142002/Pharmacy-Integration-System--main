﻿namespace Test.PharmacistUC
{
    partial class UC_P_UpdateMedicine
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Dashbord = new System.Windows.Forms.Label();
            this.txtmedNum = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtmedName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtmedID = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtmanDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txtperUnit = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAvalquantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtExpierdate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.btnsearch = new Guna.UI2.WinForms.Guna2Button();
            this.ptnRest = new Guna.UI2.WinForms.Guna2Button();
            this.ptnUpdate = new Guna.UI2.WinForms.Guna2Button();
            this.txtaddQuan = new Guna.UI2.WinForms.Guna2TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.SuspendLayout();
            // 
            // Dashbord
            // 
            this.Dashbord.AutoSize = true;
            this.Dashbord.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashbord.Location = new System.Drawing.Point(41, 36);
            this.Dashbord.Name = "Dashbord";
            this.Dashbord.Size = new System.Drawing.Size(270, 36);
            this.Dashbord.TabIndex = 3;
            this.Dashbord.Text = "Update Medicine";
            // 
            // txtmedNum
            // 
            this.txtmedNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmedNum.DefaultText = "";
            this.txtmedNum.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtmedNum.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtmedNum.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmedNum.DisabledState.Parent = this.txtmedNum;
            this.txtmedNum.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmedNum.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmedNum.FocusedState.Parent = this.txtmedNum;
            this.txtmedNum.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtmedNum.ForeColor = System.Drawing.Color.Black;
            this.txtmedNum.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmedNum.HoverState.Parent = this.txtmedNum;
            this.txtmedNum.Location = new System.Drawing.Point(115, 505);
            this.txtmedNum.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtmedNum.Name = "txtmedNum";
            this.txtmedNum.PasswordChar = '\0';
            this.txtmedNum.PlaceholderText = "";
            this.txtmedNum.SelectedText = "";
            this.txtmedNum.ShadowDecoration.Parent = this.txtmedNum;
            this.txtmedNum.Size = new System.Drawing.Size(340, 36);
            this.txtmedNum.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(121, 468);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Medicine Number";
            // 
            // txtmedName
            // 
            this.txtmedName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmedName.DefaultText = "";
            this.txtmedName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtmedName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtmedName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmedName.DisabledState.Parent = this.txtmedName;
            this.txtmedName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmedName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmedName.FocusedState.Parent = this.txtmedName;
            this.txtmedName.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtmedName.ForeColor = System.Drawing.Color.Black;
            this.txtmedName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmedName.HoverState.Parent = this.txtmedName;
            this.txtmedName.Location = new System.Drawing.Point(115, 368);
            this.txtmedName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtmedName.Name = "txtmedName";
            this.txtmedName.PasswordChar = '\0';
            this.txtmedName.PlaceholderText = "";
            this.txtmedName.SelectedText = "";
            this.txtmedName.ShadowDecoration.Parent = this.txtmedName;
            this.txtmedName.Size = new System.Drawing.Size(340, 36);
            this.txtmedName.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(121, 331);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Medicine Name";
            // 
            // txtmedID
            // 
            this.txtmedID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmedID.DefaultText = "";
            this.txtmedID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtmedID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtmedID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmedID.DisabledState.Parent = this.txtmedID;
            this.txtmedID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtmedID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmedID.FocusedState.Parent = this.txtmedID;
            this.txtmedID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtmedID.ForeColor = System.Drawing.Color.Black;
            this.txtmedID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtmedID.HoverState.Parent = this.txtmedID;
            this.txtmedID.Location = new System.Drawing.Point(115, 212);
            this.txtmedID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtmedID.Name = "txtmedID";
            this.txtmedID.PasswordChar = '\0';
            this.txtmedID.PlaceholderText = "";
            this.txtmedID.SelectedText = "";
            this.txtmedID.ShadowDecoration.Parent = this.txtmedID;
            this.txtmedID.Size = new System.Drawing.Size(340, 36);
            this.txtmedID.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(121, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Medicine ID";
            // 
            // txtmanDate
            // 
            this.txtmanDate.BorderThickness = 1;
            this.txtmanDate.CheckedState.Parent = this.txtmanDate;
            this.txtmanDate.FillColor = System.Drawing.Color.White;
            this.txtmanDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.txtmanDate.HoverState.Parent = this.txtmanDate;
            this.txtmanDate.Location = new System.Drawing.Point(116, 644);
            this.txtmanDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtmanDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtmanDate.Name = "txtmanDate";
            this.txtmanDate.ShadowDecoration.Parent = this.txtmanDate;
            this.txtmanDate.Size = new System.Drawing.Size(340, 36);
            this.txtmanDate.TabIndex = 16;
            this.txtmanDate.Value = new System.DateTime(2022, 12, 13, 21, 10, 43, 681);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(121, 607);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Manufacturing Date";
            // 
            // txtperUnit
            // 
            this.txtperUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtperUnit.DefaultText = "";
            this.txtperUnit.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtperUnit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtperUnit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtperUnit.DisabledState.Parent = this.txtperUnit;
            this.txtperUnit.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtperUnit.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtperUnit.FocusedState.Parent = this.txtperUnit;
            this.txtperUnit.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtperUnit.ForeColor = System.Drawing.Color.Black;
            this.txtperUnit.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtperUnit.HoverState.Parent = this.txtperUnit;
            this.txtperUnit.Location = new System.Drawing.Point(656, 505);
            this.txtperUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtperUnit.Name = "txtperUnit";
            this.txtperUnit.PasswordChar = '\0';
            this.txtperUnit.PlaceholderText = "";
            this.txtperUnit.SelectedText = "";
            this.txtperUnit.ShadowDecoration.Parent = this.txtperUnit;
            this.txtperUnit.Size = new System.Drawing.Size(340, 36);
            this.txtperUnit.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(662, 468);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 20);
            this.label7.TabIndex = 21;
            this.label7.Text = "Price Per Unit";
            // 
            // txtAvalquantity
            // 
            this.txtAvalquantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAvalquantity.DefaultText = "";
            this.txtAvalquantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtAvalquantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtAvalquantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtAvalquantity.DisabledState.Parent = this.txtAvalquantity;
            this.txtAvalquantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtAvalquantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtAvalquantity.FocusedState.Parent = this.txtAvalquantity;
            this.txtAvalquantity.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtAvalquantity.ForeColor = System.Drawing.Color.Black;
            this.txtAvalquantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtAvalquantity.HoverState.Parent = this.txtAvalquantity;
            this.txtAvalquantity.Location = new System.Drawing.Point(656, 322);
            this.txtAvalquantity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAvalquantity.Name = "txtAvalquantity";
            this.txtAvalquantity.PasswordChar = '\0';
            this.txtAvalquantity.PlaceholderText = "";
            this.txtAvalquantity.SelectedText = "";
            this.txtAvalquantity.ShadowDecoration.Parent = this.txtAvalquantity;
            this.txtAvalquantity.Size = new System.Drawing.Size(340, 36);
            this.txtAvalquantity.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(662, 288);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Available Quantity";
            // 
            // txtExpierdate
            // 
            this.txtExpierdate.BorderThickness = 1;
            this.txtExpierdate.CheckedState.Parent = this.txtExpierdate;
            this.txtExpierdate.FillColor = System.Drawing.Color.White;
            this.txtExpierdate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.txtExpierdate.HoverState.Parent = this.txtExpierdate;
            this.txtExpierdate.Location = new System.Drawing.Point(656, 212);
            this.txtExpierdate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtExpierdate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtExpierdate.Name = "txtExpierdate";
            this.txtExpierdate.ShadowDecoration.Parent = this.txtExpierdate;
            this.txtExpierdate.Size = new System.Drawing.Size(340, 36);
            this.txtExpierdate.TabIndex = 18;
            this.txtExpierdate.Value = new System.DateTime(2022, 12, 13, 21, 10, 43, 681);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(662, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "Expire Date";
            // 
            // btnsearch
            // 
            this.btnsearch.BorderRadius = 19;
            this.btnsearch.BorderThickness = 1;
            this.btnsearch.CheckedState.Parent = this.btnsearch;
            this.btnsearch.CustomImages.Parent = this.btnsearch;
            this.btnsearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.White;
            this.btnsearch.HoverState.BorderColor = System.Drawing.Color.Black;
            this.btnsearch.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.btnsearch.HoverState.Parent = this.btnsearch;
            this.btnsearch.Location = new System.Drawing.Point(339, 256);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.ShadowDecoration.Parent = this.btnsearch;
            this.btnsearch.Size = new System.Drawing.Size(116, 34);
            this.btnsearch.TabIndex = 23;
            this.btnsearch.Text = "Search";
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // ptnRest
            // 
            this.ptnRest.BorderRadius = 19;
            this.ptnRest.BorderThickness = 1;
            this.ptnRest.CheckedState.Parent = this.ptnRest;
            this.ptnRest.CustomImages.Parent = this.ptnRest;
            this.ptnRest.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptnRest.ForeColor = System.Drawing.Color.White;
            this.ptnRest.HoverState.BorderColor = System.Drawing.Color.Black;
            this.ptnRest.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.ptnRest.HoverState.Parent = this.ptnRest;
            this.ptnRest.Location = new System.Drawing.Point(866, 613);
            this.ptnRest.Name = "ptnRest";
            this.ptnRest.ShadowDecoration.Parent = this.ptnRest;
            this.ptnRest.Size = new System.Drawing.Size(130, 45);
            this.ptnRest.TabIndex = 24;
            this.ptnRest.Text = "Clear";
            this.ptnRest.Click += new System.EventHandler(this.ptnRest_Click);
            // 
            // ptnUpdate
            // 
            this.ptnUpdate.BorderRadius = 19;
            this.ptnUpdate.BorderThickness = 1;
            this.ptnUpdate.CheckedState.Parent = this.ptnUpdate;
            this.ptnUpdate.CustomImages.Parent = this.ptnUpdate;
            this.ptnUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptnUpdate.ForeColor = System.Drawing.Color.White;
            this.ptnUpdate.HoverState.BorderColor = System.Drawing.Color.Black;
            this.ptnUpdate.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.ptnUpdate.HoverState.Parent = this.ptnUpdate;
            this.ptnUpdate.Location = new System.Drawing.Point(656, 613);
            this.ptnUpdate.Name = "ptnUpdate";
            this.ptnUpdate.ShadowDecoration.Parent = this.ptnUpdate;
            this.ptnUpdate.Size = new System.Drawing.Size(129, 45);
            this.ptnUpdate.TabIndex = 25;
            this.ptnUpdate.Text = "Update";
            this.ptnUpdate.Click += new System.EventHandler(this.ptnUpdate_Click);
            // 
            // txtaddQuan
            // 
            this.txtaddQuan.BorderColor = System.Drawing.Color.Green;
            this.txtaddQuan.BorderThickness = 3;
            this.txtaddQuan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtaddQuan.DefaultText = "0";
            this.txtaddQuan.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtaddQuan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtaddQuan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtaddQuan.DisabledState.Parent = this.txtaddQuan;
            this.txtaddQuan.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtaddQuan.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtaddQuan.FocusedState.Parent = this.txtaddQuan;
            this.txtaddQuan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddQuan.ForeColor = System.Drawing.Color.Black;
            this.txtaddQuan.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtaddQuan.HoverState.Parent = this.txtaddQuan;
            this.txtaddQuan.Location = new System.Drawing.Point(897, 377);
            this.txtaddQuan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtaddQuan.Name = "txtaddQuan";
            this.txtaddQuan.PasswordChar = '\0';
            this.txtaddQuan.PlaceholderText = "";
            this.txtaddQuan.SelectedText = "";
            this.txtaddQuan.SelectionStart = 1;
            this.txtaddQuan.ShadowDecoration.Parent = this.txtaddQuan;
            this.txtaddQuan.Size = new System.Drawing.Size(99, 36);
            this.txtaddQuan.TabIndex = 26;
            this.txtaddQuan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(795, 388);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 16);
            this.label8.TabIndex = 27;
            this.label8.Text = "Add Quantity";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // UC_P_UpdateMedicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtaddQuan);
            this.Controls.Add(this.ptnUpdate);
            this.Controls.Add(this.ptnRest);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtperUnit);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAvalquantity);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtExpierdate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtmanDate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtmedNum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtmedName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtmedID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Dashbord);
            this.Name = "UC_P_UpdateMedicine";
            this.Size = new System.Drawing.Size(1110, 777);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Dashbord;
        private Guna.UI2.WinForms.Guna2TextBox txtmedNum;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txtmedName;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtmedID;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2DateTimePicker txtmanDate;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txtperUnit;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txtAvalquantity;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2DateTimePicker txtExpierdate;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button btnsearch;
        private Guna.UI2.WinForms.Guna2Button ptnRest;
        private Guna.UI2.WinForms.Guna2Button ptnUpdate;
        private Guna.UI2.WinForms.Guna2TextBox txtaddQuan;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
